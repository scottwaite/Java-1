Created By: Scott Waite
Course: Java 1
Instructor: Gyasi Story
Assignment: Mastering the Fundamentals
Date: October 10, 2014


https://github.com/scottwaite/Java-1