Created By: Scott Waite
Course: Java 1
Instructor: Gyasi Story
Assignment: Mastering the Fundamentals
Date: September 7, 2014


https://github.com/scottwaite/Java-1